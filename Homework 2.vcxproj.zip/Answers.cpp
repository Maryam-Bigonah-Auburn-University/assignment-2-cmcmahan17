#include <iostream>
#include "Question_1.cpp"
//#include "Question_2.cpp"
//#include "Question_3.cpp"

int main()
{
	std::cout << "Question 1:\n";
	Answer_1();

	//std::cout << "\n \nQuestion 2:\n";
	//Answer_2();

	//std::cout << "\n \nQuestion 3:\n";
	//Answer_3();

	return 0;
}