#include <iostream>

static int Answer_2()
{


}