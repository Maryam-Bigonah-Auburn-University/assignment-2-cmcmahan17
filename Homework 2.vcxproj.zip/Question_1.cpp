#include <iostream>

bool isLeapYear(int year);
int getCenturyValue(int year);
int getYearValue(int year);
int getMonthValue(int month, int year);

static int Answer_1()
{
	int day;
	int month;
	int year;
	int sum = 0;
	int weekday = 0;

	std::cout << "Enter the month (MM): ";
	std::cin >> month;

	std::cout << "Enter the day (DD): ";
	std::cin >> day;

	std::cout << "Enter the year: ";
	std::cin >> year;

	sum = getMonthValue(month, year) + getYearValue(year) + getCenturyValue(year);
	weekday = sum % 7;
	switch (weekday) 
	{
	case 0: 
		std::cout << "Sunday";
	case 1:
		std::cout << "Monday";
	case 2:
		std::cout << "Tuesday";
	case 3: 
		std::cout << "Wednesday";
	case 4:
		std::cout << "Thursday";
	case 5:
		std::cout << "Friday";
	case 6:
		std::cout << "Saturday";
	}

	return 0;
}

bool isLeapYear(int year)
{
	int isLeap;
	isLeap = year % 4;
	if (isLeap == 0)
	{
		return true;
	}
	else
	{
		return false;
	}
}

int getCenturyValue(int year)
{
	year /= 100;
	year = year - (year % 1);
	return (3 - (year % 5)) * 2;
}

int getYearValue(int year)
{
	year /= 100;
	year = year % 1;
	return year + floor(year/4);
}

int getMonthValue(int month, int year)
{
	switch (month) 
	{
		case 1:
			if (isLeapYear(year))
			{
				return 6;
			}
			else
			{
				return 0;
			}
		case 2:
			if (isLeapYear(year))
			{
				return 2;
			}
			else
			{
				return 3;
			}
		case 3:
			return 3;
		case 4:
			return 6;
		case 5:
			return 1;
		case 6:
			return 4;
		case 7:
			return 6;
		case 8:
			return 2;
		case 9:
			return 5;
		case 10:
			return 0;
		case 11:
			return 3;
		case 12:
			return 5;
	}
}