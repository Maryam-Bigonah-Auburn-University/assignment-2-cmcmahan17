#include <iostream>

static int Answer_3()
{


}